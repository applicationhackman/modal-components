import Ember from 'ember';
import layout from '../templates/components/modal-dialog-footer';

export default Ember.Component.extend({
 classNames : "modal-footer",
  layout: layout,
  footer : Em.computed(function(){
  		return this.hasOwnProperty("footeractions");
  }),
  didInsertElement : function () {
  	
  	console.log("docFooterActions of ",this, " this footer ",this.get("footer"),this.get("footeractions"));

  	

  },



});

import Ember from 'ember';
import layout from '../templates/components/modal-tabs';

export default Ember.Component.extend({
  layout: layout
});

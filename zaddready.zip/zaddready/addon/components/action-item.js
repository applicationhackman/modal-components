import Ember from 'ember';
import layout from '../templates/components/action-item';

export default Ember.Component.extend({
  layout: layout,
  init : function(){
  	this.set("tagName",this.get("tagName"));
  	this._super();
  },
  click : function(e,ui){
  	this.send("triggerAction",e,ui);
  },
  actions : {
	  triggerAction : function()
    {

	  		var obj = {};
	  		var target = (this.get("target") === null) ? this.container.lookup(this.get("parentView.target"))  :  this.container.lookup(this.get("target"));

  			if(this.hasOwnProperty("action") && this.action !==  undefined && this.action !==  null)
  			{  		
  	  			target.send(this.action,obj,this);
  	  	}

	  		if(this.hasOwnProperty("dialog"))
	  		{
	  			this.send("setDialog",this,target);
	  		}		

	  		if(this.hasOwnProperty("dialogClose") && this.get('dialogClose')){
	  			this.send("closeDialog",obj);
	  		}

	  	},
	  	setDialog : function(obj,target){
          target.set(obj.dialog,true);  
  		},
  		closeDialog : function(){

        
        var target = this.get("parentView.target");
        var dialogname = this.get("parentView.name");

        target = (target === null) ? target : this.get("parentView.parentView.target");
        dialogname = (dialogname === undefined) ?  this.get("parentView.parentView.name") : dialogname;

  			target.set(dialogname,false);

  		}

  	}
});

import Ember from 'ember';
import layout from '../templates/components/tab-content';

export default Ember.Component.extend({
  layout: layout,
  classNames:["tab-pane"],
  classNameBindings :["state"],
  attributeBindings : ["role"],
  didInsertElement : function  () {
  	this.set("state", this.get("modal.state"));
  }

});

import Ember from 'ember';
import layout from '../templates/components/tab-item';

export default Ember.Component.extend({
  layout: layout,
  tagName:"li",
  classNameBindings :["state"],
  attributeBindings : ["role"],
  role:"presentation",
  click : function(){

      var tabs  = this.get("parentView.modal");
      var selected = this.get("modal");

      tabs.filter(function(tab){

        if(tab === selected){
            Em.set(tab,"state","active");
        }else{
          Em.set(tab,"state","");
        }

      })

  },
  didInsertElement : function  () {
	  var a= this.$().find("a"); 	
  	a.attr("href","#"+this.get("modal.id"));
    this.set("tabid",this.get("modal.id"));
  	var cobj  = this;

  	this.set("state", this.get("modal.state"));

    this.addObserver("parentView.modal.state",function(){ 
     this.send("setState");
    })
  	
  },
  actions : {
    setState : function(){

        console.log("state has changed");

    		// this.set("modal.state", this.get("modal.state"));
    }
  }
});

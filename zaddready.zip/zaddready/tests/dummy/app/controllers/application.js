import Em from 'ember';


export default Em.Controller.extend({

		actions : {

			createDocument : function  () {
				console.log("creating document ");
			}
		}

})